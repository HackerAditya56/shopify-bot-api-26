--
-- PostgreSQL database dump
--

\restrict aD6saFdcbcYK2Lnmffem97UHtoHINERcjAC5EThkIrDdRSRZsxve6RAaNG4bbhp

-- Dumped from database version 18.6 (Ubuntu 18.6-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.idx_payment_tracks_user;
DROP INDEX IF EXISTS public.idx_payment_tracks_status;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.receipts DROP CONSTRAINT IF EXISTS receipts_receipt_id_key;
ALTER TABLE IF EXISTS ONLY public.receipts DROP CONSTRAINT IF EXISTS receipts_pkey;
ALTER TABLE IF EXISTS ONLY public.proxies DROP CONSTRAINT IF EXISTS proxies_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_tracks DROP CONSTRAINT IF EXISTS payment_tracks_pkey;
ALTER TABLE IF EXISTS ONLY public.global_proxies DROP CONSTRAINT IF EXISTS global_proxies_proxy_key;
ALTER TABLE IF EXISTS ONLY public.global_proxies DROP CONSTRAINT IF EXISTS global_proxies_pkey;
ALTER TABLE IF EXISTS ONLY public.gate_status DROP CONSTRAINT IF EXISTS gate_status_pkey;
ALTER TABLE IF EXISTS ONLY public.codes DROP CONSTRAINT IF EXISTS codes_pkey;
ALTER TABLE IF EXISTS ONLY public.bot_state DROP CONSTRAINT IF EXISTS bot_state_pkey;
ALTER TABLE IF EXISTS ONLY public.bot_settings DROP CONSTRAINT IF EXISTS bot_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.banned_users DROP CONSTRAINT IF EXISTS banned_users_pkey;
ALTER TABLE IF EXISTS public.receipts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.proxies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.global_proxies ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.receipts_id_seq;
DROP TABLE IF EXISTS public.receipts;
DROP SEQUENCE IF EXISTS public.proxies_id_seq;
DROP TABLE IF EXISTS public.proxies;
DROP TABLE IF EXISTS public.payment_tracks;
DROP SEQUENCE IF EXISTS public.global_proxies_id_seq;
DROP TABLE IF EXISTS public.global_proxies;
DROP TABLE IF EXISTS public.gate_status;
DROP TABLE IF EXISTS public.codes;
DROP TABLE IF EXISTS public.bot_state;
DROP TABLE IF EXISTS public.bot_settings;
DROP TABLE IF EXISTS public.banned_users;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: banned_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banned_users (
    user_id bigint NOT NULL,
    banned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: bot_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_settings (
    key text NOT NULL,
    value text
);


--
-- Name: bot_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_state (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.codes (
    code text NOT NULL,
    credits integer,
    claimed_by bigint,
    claimed_at timestamp without time zone,
    plan_name text,
    duration_seconds bigint,
    created_by bigint,
    expires_at timestamp without time zone
);


--
-- Name: gate_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gate_status (
    gate text NOT NULL,
    is_enabled boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: global_proxies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_proxies (
    id integer NOT NULL,
    proxy text NOT NULL,
    status text DEFAULT 'active'::text,
    fail_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    cooldown_until timestamp without time zone,
    last_used timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: global_proxies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.global_proxies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: global_proxies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.global_proxies_id_seq OWNED BY public.global_proxies.id;


--
-- Name: payment_tracks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_tracks (
    track_id text NOT NULL,
    user_id bigint,
    plan text,
    price_usd real,
    pay_amount text,
    currency text,
    network text,
    address text,
    invoice_url text,
    order_id text,
    status text DEFAULT 'Pending'::text,
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone
);


--
-- Name: proxies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proxies (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    proxy text NOT NULL,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: proxies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proxies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proxies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proxies_id_seq OWNED BY public.proxies.id;


--
-- Name: receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipts (
    id integer NOT NULL,
    receipt_id text,
    user_id bigint,
    plan text,
    amount_paid real,
    purchased_on timestamp without time zone,
    expires_on timestamp without time zone
);


--
-- Name: receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receipts_id_seq OWNED BY public.receipts.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    username text,
    credits integer DEFAULT 0,
    cc_checked integer DEFAULT 0,
    cc_charged integer DEFAULT 0,
    joined_at timestamp without time zone,
    cc_charged_lifetime integer DEFAULT 0,
    cc_approved_lifetime integer DEFAULT 0,
    cc_declined_lifetime integer DEFAULT 0,
    first_name text,
    is_premium integer DEFAULT 0,
    premium_expiry timestamp without time zone,
    cards_generated integer DEFAULT 0,
    sk_checked integer DEFAULT 0,
    sk_charged integer DEFAULT 0
);


--
-- Name: global_proxies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_proxies ALTER COLUMN id SET DEFAULT nextval('public.global_proxies_id_seq'::regclass);


--
-- Name: proxies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxies ALTER COLUMN id SET DEFAULT nextval('public.proxies_id_seq'::regclass);


--
-- Name: receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts ALTER COLUMN id SET DEFAULT nextval('public.receipts_id_seq'::regclass);


--
-- Data for Name: banned_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banned_users (user_id, banned_at) FROM stdin;
\.


--
-- Data for Name: bot_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bot_settings (key, value) FROM stdin;
gifs	off
hide_names	off
\.


--
-- Data for Name: bot_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bot_state (key, value, updated_at) FROM stdin;
last_seen	2026-10-16T23:59:52.824606	2026-10-16 23:59:52.825573
\.


--
-- Data for Name: codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.codes (code, credits, claimed_by, claimed_at, plan_name, duration_seconds, created_by, expires_at) FROM stdin;
WIZX-HDL9P1TVSA-CHK	99999999	8875733716	2026-10-01 18:14:03.752391	ꕶᴡ𝖎ғ†	86400	8423281554	2026-10-02 18:14:03.752333
WIZX-W8K5PT5TD1-CHK	99999999	\N	\N	ꕶᴡ𝖎ғ†	86400	8423281554	\N
\.


--
-- Data for Name: gate_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gate_status (gate, is_enabled, updated_at) FROM stdin;
st	t	2026-09-30 05:31:17.439867
sh	t	2026-09-30 05:31:17.439867
sp	t	2026-09-30 05:31:17.439867
hc	t	2026-09-30 05:31:17.439867
pf	t	2026-09-30 05:31:17.439867
vbv	t	2026-09-30 05:31:17.439867
ft	t	2026-09-30 05:31:17.439867
bl	t	2026-09-30 05:31:17.439867
pp	t	2026-09-30 05:31:17.439867
at	t	2026-09-30 05:31:17.439867
pw	t	2026-09-30 05:31:17.439867
b3	t	2026-09-30 05:31:17.439867
py	t	2026-09-30 05:31:17.439867
nmi	t	2026-09-30 05:31:17.439867
nmi2	t	2026-09-30 05:31:17.439867
sk	t	2026-09-30 05:31:17.439867
chk	t	2026-09-30 05:31:17.439867
cl	t	2026-09-30 05:31:17.439867
msh	t	2026-09-30 05:31:17.439867
mst	t	2026-09-30 05:31:17.439867
msk	t	2026-09-30 05:31:17.439867
mchk	t	2026-09-30 05:31:17.439867
mpp	t	2026-09-30 05:31:17.439867
scr	t	2026-09-30 05:31:17.439867
clean	t	2026-09-30 05:31:17.439867
ch	t	2026-10-04 04:22:43.846823
pg	t	2026-10-07 16:29:44.634129
mrz	f	2026-10-14 15:03:48.639785
rz	f	2026-10-14 15:03:50.91367
pyu	f	2026-10-14 15:04:05.581443
\.


--
-- Data for Name: global_proxies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_proxies (id, proxy, status, fail_count, success_count, cooldown_until, last_used, created_at) FROM stdin;
1	1316 p8zishJyoWbr p101.squidproxies.com 9016	active	0	0	\N	\N	2026-09-30 08:24:02.006551
2	1316 p8zishJyoWbr p101.squidproxies.com 9017	active	0	0	\N	\N	2026-09-30 08:24:02.01392
3	1316 p8zishJyoWbr p102.squidproxies.com 9015	active	0	0	\N	\N	2026-09-30 08:24:02.016703
4	1316 p8zishJyoWbr p102.squidproxies.com 9016	active	0	0	\N	\N	2026-09-30 08:24:02.019005
5	1316 p8zishJyoWbr p103.squidproxies.com 9014	active	0	0	\N	\N	2026-09-30 08:24:02.021045
6	1316 p8zishJyoWbr p103.squidproxies.com 9015	active	0	0	\N	\N	2026-09-30 08:24:02.023405
7	1316 p8zishJyoWbr p103.squidproxies.com 9016	active	0	0	\N	\N	2026-09-30 08:24:02.025523
8	1315 BI!QjHDp9d&P p101.squidproxies.com 9013	active	0	0	\N	\N	2026-09-30 08:24:02.027452
9	1315 BI!QjHDp9d&P p102.squidproxies.com 9013	active	0	0	\N	\N	2026-09-30 08:24:02.029796
10	1315 BI!QjHDp9d&P p103.squidproxies.com 9013	active	0	0	\N	\N	2026-09-30 08:24:02.031984
11	1331 GxdGBwgR$6pZ p101.squidproxies.com 9051	active	0	0	\N	\N	2026-09-30 08:24:02.034743
12	1331 GxdGBwgR$6pZ p101.squidproxies.com 9053	active	0	0	\N	\N	2026-09-30 08:24:02.037787
13	1331 GxdGBwgR$6pZ p102.squidproxies.com 9051	active	0	0	\N	\N	2026-09-30 08:24:02.040022
14	1331 GxdGBwgR$6pZ p102.squidproxies.com 9053	active	0	0	\N	\N	2026-09-30 08:24:02.042341
15	1331 GxdGBwgR$6pZ p103.squidproxies.com 9050	active	0	0	\N	\N	2026-09-30 08:24:02.044816
16	1331 GxdGBwgR$6pZ p103.squidproxies.com 9052	active	0	0	\N	\N	2026-09-30 08:24:02.047494
17	1331 GxdGBwgR$6pZ p103.squidproxies.com 9053	active	0	0	\N	\N	2026-09-30 08:24:02.050835
18	3dfw7c6x oSeqx0CNeV0k 103.183.121.128 58122	active	0	0	\N	\N	2026-10-02 13:59:06.8665
19	azqdr5vn 71WCPuMwyc72 103.183.121.211 11657	active	0	0	\N	\N	2026-10-02 13:59:06.871491
20	y7g4dd8d Buw96jtGFKA5 103.183.121.59 34219	active	0	0	\N	\N	2026-10-02 13:59:06.873269
21	zqrn9y5d zQRN9y5d 103.156.91.173 58798	active	0	0	\N	\N	2026-10-02 13:59:06.87505
22	dz46cabj ksuRcKlNqJMU 103.161.113.230 18491	active	0	0	\N	\N	2026-10-02 13:59:06.876694
23	purevpn0s8732217 i67s60ep px121001.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.878678
24	purevpn0s8732217 i67s60ep px121101.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.880356
25	purevpn0s8732217 i67s60ep px591203.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.8825
26	purevpn0s8732217 i67s60ep px121102.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.884171
27	purevpn0s8732217 i67s60ep px591201.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.886089
28	RrkJjUqfT jYEH6Emdg 82.117.94.14 63126	active	0	0	\N	\N	2026-10-02 13:59:06.887636
29	LMaUQSHZX XK5PeFfaf 45.86.79.41 64628	active	0	0	\N	\N	2026-10-02 13:59:06.889132
30	purevpn0s8732217 i67s60ep px022409.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.890831
31	purevpn0s8732217 i67s60ep px022408.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.892477
32	purevpn0s8732217 i67s60ep px241104.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.894157
33	purevpn0s8732217 i67s60ep px241102.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.895836
34	purevpn0s8732217 i67s60ep px023005.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.897753
35	1DnugnypC 4yPtzMd3f 193.254.17.97 64708	active	0	0	\N	\N	2026-10-02 13:59:06.899753
36	purevpn0s8732217 i67s60ep px022507.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.901628
37	purevpn0s8732217 i67s60ep px152201.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.903268
38	nWtrJqsb RYYEE72Y 194.33.9.114 64170	active	0	0	\N	\N	2026-10-02 13:59:06.905093
39	nWtrJqsb RYYEE72Y 194.33.9.136 49520	active	0	0	\N	\N	2026-10-02 13:59:06.906875
40	purevpn0s8732217 i67s60ep px043006.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.908705
41	purevpn0s8732217 i67s60ep px040706.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.910572
42	purevpn0s8732217 i67s60ep px051703.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.91216
43	oldg6k2r oLdG6k2R 135.148.117.75 59813	active	0	0	\N	\N	2026-10-02 13:59:06.914098
44	purevpn0s8732217 i67s60ep px040805.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.915806
45	purevpn0s8732217 i67s60ep px440401.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.917629
46	purevpn0s8732217 i67s60ep px032004.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.919348
47	purevpn0s8732217 i67s60ep px400408.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.92126
48	fwos7n0b fWOS7n0B 51.195.198.170 36647	active	0	0	\N	\N	2026-10-02 13:59:06.923123
49	purevpn0s8732217 i67s60ep px400501.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.925365
50	purevpn0s8732217 i67s60ep px591801.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.927553
51	purevpn0s8732217 i67s60ep px380101.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.929574
52	purevpn0s8732217 i67s60ep px520401.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.931597
53	yosz6g8y yOSZ6g8y 135.148.98.200 59746	active	0	0	\N	\N	2026-10-02 13:59:06.93322
54	purevpn0s8732217 i67s60ep px1260303.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.935648
55	purevpn0s8732217 i67s60ep px080702.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.937839
56	purevpn0s8732217 i67s60ep px420602.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.939809
57	purevpn0s8732217 i67s60ep px180801.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.941685
58	purevpn0s8732217 i67s60ep px051003.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:06.944022
59	nWtrJqsb RYYEE72Y 45.145.162.63 58536	active	0	0	\N	\N	2026-10-02 13:59:06.946533
60	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 au-syd.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:06.94855
61	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 se-got.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:06.950522
62	s6202052810029 78496978 202.28.17.8 8080	active	0	0	\N	\N	2026-10-02 13:59:32.320735
63	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 is-rey.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.323997
64	purevpn0s8732217 i67s60ep px031901.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 13:59:32.326307
65	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 md-chi.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.32843
66	5K05CT880J2D VE1MSDRGFDZB 175.29.135.7 5433	active	0	0	\N	\N	2026-10-02 13:59:32.330728
67	s6302012630029 Sick22241 202.28.17.5 8080	active	0	0	\N	\N	2026-10-02 13:59:32.332697
68	s6402027622069 pass2564 202.28.17.5 8080	active	0	0	\N	\N	2026-10-02 13:59:32.334793
69	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 at-wie.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.336717
70	1401 FVRHsSXw2DNK p103.squidproxies.com 9238	active	0	0	\N	\N	2026-10-02 13:59:32.339021
71	naveed Qwerty_123ABC 103.204.108.142 12345	active	0	0	\N	\N	2026-10-02 13:59:32.340913
72	naveed Qwerty_123ABC 196.244.48.124 12345	active	0	0	\N	\N	2026-10-02 13:59:32.342874
73	1439 jqvFsDEZ&%Sm p101.squidproxies.com 9292	active	0	0	\N	\N	2026-10-02 13:59:32.344707
74	S6104011620031 ning26304 202.28.17.5 8080	active	0	0	\N	\N	2026-10-02 13:59:32.346529
75	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 de-ber.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.348193
76	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 th-ban.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.350102
77	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 ca-mon.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.352216
78	1439 jqvFsDEZ&%Sm p103.squidproxies.com 9291	active	0	0	\N	\N	2026-10-02 13:59:32.355728
79	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 id-jak.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.358186
80	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 pl-tor.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.360936
81	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 au-bri.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.363379
82	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 se-kis.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.365282
83	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 au-mel.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.367088
84	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 ca-van.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.368716
85	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 tw-tai.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.370677
86	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 de-fra.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.372515
87	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 mx-mex.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.37507
88	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 cy-lim.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.377425
89	5K05CT880J2D VE1MSDRGFDZB 37.218.219.8 5433	active	0	0	\N	\N	2026-10-02 13:59:32.379605
90	llewellynashleybowen rNXaRJfNPN233zw 136.179.19.164 3128	active	0	0	\N	\N	2026-10-02 13:59:32.381787
91	799JRELTBPAE F7BQ7D3EQSQA 175.29.133.8 5433	active	0	0	\N	\N	2026-10-02 13:59:32.383787
92	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 be-bru.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.385999
93	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 se-sto.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.387788
94	s6303061616175 0884267191 202.28.17.5 8080	active	0	0	\N	\N	2026-10-02 13:59:32.389446
95	socialwire 87xb2kziRk4xa 153.121.71.115 822	active	0	0	\N	\N	2026-10-02 13:59:32.391196
96	s6301074610292 za0643250344 202.28.17.8 8080	active	0	0	\N	\N	2026-10-02 13:59:32.39384
97	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 it-mil.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.396083
98	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 sk-bra.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.398345
99	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 im-bal.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.400283
100	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 fr-par.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.402244
101	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 ch-zur.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.404443
102	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 in-ban.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.406504
103	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 my-kua.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.408281
104	naveed Qwerty_123ABC 196.244.48.26 12345	active	0	0	\N	\N	2026-10-02 13:59:32.410275
105	1439 jqvFsDEZ&%Sm p102.squidproxies.com 9292	active	0	0	\N	\N	2026-10-02 13:59:32.412004
106	1351 IBd1Fk5CuUNZ p103.squidproxies.com 9087	active	0	0	\N	\N	2026-10-02 13:59:32.414037
107	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 br-sao.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 13:59:32.41621
108	naveed Qwerty_123ABC 196.244.48.126 12345	active	0	0	\N	\N	2026-10-02 13:59:32.418427
109	patcharapons calendar 202.28.17.5 8080	active	0	0	\N	\N	2026-10-02 13:59:32.420545
110	purevpn0s11340994 ak3t35fp px031901.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.867248
111	purevpn0s7397024 6CU9ZvexLGTqpB px043006.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.870144
112	purevpn0s11340994 ak3t35fp px591801.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.871916
113	purevpn0s2232045 hww8fqbr72j0 px051003.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.874027
114	purevpn0s2232045 hww8fqbr72j0 px022409.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.876207
115	purevpn0s11383538 43z2vhwa px051703.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.877956
116	purevpn0s11340994 ak3t35fp px051703.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.879505
117	purevpn0s7397024 6CU9ZvexLGTqpB px051703.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.882439
118	purevpn0s2232045 hww8fqbr72j0 px051703.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.884666
119	purevpn0s11383538 43z2vhwa px400501.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.886549
120	purevpn0s7397024 6CU9ZvexLGTqpB px400501.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.888822
121	purevpn0s11340994 ak3t35fp px400501.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.890596
122	purevpn0s2232045 hww8fqbr72j0 px400501.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.89229
123	purevpn0s11383538 43z2vhwa px023005.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.894222
124	purevpn0s11340994 ak3t35fp px023005.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.895752
125	purevpn0s2232045 hww8fqbr72j0 px023005.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.897538
126	purevpn0s11383538 43z2vhwa px051003.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.899955
127	purevpn0s11383538 43z2vhwa px043006.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.90177
128	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 nl-ams.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 14:00:12.903473
129	harishankarchoubey HvCjWdoIrK6szj8v 136.179.19.164 3128	active	0	0	\N	\N	2026-10-02 14:00:12.905281
130	jantawan.ban jantawan.ban proxy.sru.ac.th 8080	active	0	0	\N	\N	2026-10-02 14:00:12.907487
131	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 au-per.pvdata.host 8080	active	0	0	\N	\N	2026-10-02 14:00:12.909702
132	purevpn0s11383538 43z2vhwa px032004.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.911692
133	purevpn0s11340994 ak3t35fp px591201.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.913675
134	purevpn0s11340994 ak3t35fp px591203.pointtoserver.com 10780	active	0	0	\N	\N	2026-10-02 14:00:12.91555
135	meetthejack 8ohlsid7hlPenEdsAbQ uk-free-proxy.g-w.info 59782	active	0	0	\N	\N	2026-10-13 18:39:08.2166
136	dagandnorb EdsAbQuamAn999 in-free-proxy.g-w.info 59783	active	0	0	\N	\N	2026-10-13 18:39:08.222086
137	user3proxyserver huccuAn_oc7o87hubhjYY us-free-proxy.g-w.info 59781	active	0	0	\N	\N	2026-10-13 18:39:08.22589
138	diehard33 3liubjnixc8456789i ca-free-proxy.g-w.info 59785	active	0	0	\N	\N	2026-10-13 18:39:08.228923
139	smoothysuck ublIUnbiybkvDfgg de-free-proxy.g-w.info 59784	active	0	0	\N	\N	2026-10-13 18:39:08.230876
152	hughmuir2 lisamarie11 hk1.cactussstp.com 81	active	0	0	\N	\N	2026-10-13 18:48:56.964874
153	uncpjndo w77Ebc0h2A hk1.cactussstp.com 3129	active	0	0	\N	\N	2026-10-13 18:48:56.970302
154	uncpjndo w77Ebc0h2A hk1.cactussstp.com 81	active	0	0	\N	\N	2026-10-13 18:48:56.973611
155	bvmbsmie shibby2511 hk1.cactussstp.com 3129	active	0	0	\N	\N	2026-10-13 18:48:56.976186
156	yefprelf dr2gsmab hk1.cactussstp.com 3129	active	0	0	\N	\N	2026-10-13 18:48:56.978901
157	bvmbsmie shibby2511 hk1.cactussstp.com 81	active	0	0	\N	\N	2026-10-13 18:48:56.98129
158	hughmuir2 lisamarie11 hk1.cactussstp.com 8080	active	0	0	\N	\N	2026-10-13 18:48:56.983183
159	uncpjndo w77Ebc0h2A hk1.cactussstp.com 8080	active	0	0	\N	\N	2026-10-13 18:48:56.990631
160	yefprelf dr2gsmab hk1.cactussstp.com 81	active	0	0	\N	\N	2026-10-13 18:48:56.994285
161	hughmuir2 lisamarie11 hk1.cactussstp.com 3129	active	0	0	\N	\N	2026-10-13 18:48:56.996743
162	yefprelf dr2gsmab hk1.cactussstp.com 8080	active	0	0	\N	\N	2026-10-13 18:48:56.999916
163	bvmbsmie shibby2511 hk1.cactussstp.com 8080	active	0	0	\N	\N	2026-10-13 18:48:57.003379
166	xnqy0n3r xNQY0n3r 103.183.118.118 31374	active	0	0	\N	\N	2026-10-15 16:09:50.087441
167	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 jp-tok.pvdata.host 8080	active	0	0	\N	\N	2026-10-15 16:09:50.089862
169	g2rTXpNfPdcw2fzGtWKp62yH nizar1elad2 lu-lux.pvdata.host 8080	active	0	0	\N	\N	2026-10-15 16:09:50.093516
170	s6402013510115 s1609900520681 202.28.17.8 8080	active	0	0	\N	\N	2026-10-15 16:09:50.095691
171	p2s_proxy oazaCentric quebec.oaza.rs 8899	active	0	0	\N	\N	2026-10-15 16:09:50.097799
175	s6003026810028 1720800122226 202.28.17.8 8080	active	0	0	\N	\N	2026-10-15 16:09:50.103521
179	s6402011520288 surikan123 202.28.17.8 8080	active	0	0	\N	\N	2026-10-15 16:09:50.10848
183	s5802016810053 1549900215617 202.28.17.8 8080	active	0	0	\N	\N	2026-10-15 16:09:50.113978
184	210470 YTrgy66CBtj2 152.232.93.183 8800	active	0	0	\N	\N	2026-10-15 16:09:50.115964
185	210470 YTrgy66CBtj2 152.232.93.83 8800	active	0	0	\N	\N	2026-10-15 16:09:50.117666
186	210470 YTrgy66CBtj2 152.232.93.200 8800	active	0	0	\N	\N	2026-10-15 16:09:50.119714
187	210470 YTrgy66CBtj2 152.232.93.130 8800	active	0	0	\N	\N	2026-10-15 16:09:50.12158
188	210470 YTrgy66CBtj2 152.232.93.120 8800	active	0	0	\N	\N	2026-10-15 16:09:50.123161
\.


--
-- Data for Name: payment_tracks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_tracks (track_id, user_id, plan, price_usd, pay_amount, currency, network, address, invoice_url, order_id, status, created_at, paid_at) FROM stdin;
6abe9e4926849c826f0bd2b8	8875733716	swift	3	3			https://plisio.net/invoice/6abe9e4926849c826f0bd2b8	https://plisio.net/invoice/6abe9e4926849c826f0bd2b8	CHKXWIZ_8875733716_swift_1790877244	Pending	2026-10-01 17:54:20.135644	\N
6ac681b1e8aa5225f402437e	8388267028	swift	3	3			https://plisio.net/invoice/6ac681b1e8aa5225f402437e	https://plisio.net/invoice/6ac681b1e8aa5225f402437e	CHKXWIZ_8388267028_swift_1791394218	Paid	2026-10-07 17:30:28.156881	2026-10-07 18:38:47.616431
6ac7ac173bbb8f908902bc6a	8875733716	swift	3	3			https://plisio.net/invoice/6ac7ac173bbb8f908902bc6a	https://plisio.net/invoice/6ac7ac173bbb8f908902bc6a	CHKXWIZ_8875733716_swift_1791470613	Paid	2026-10-08 14:43:37.435126	2026-10-08 15:44:07.491976
6ac89ed03e61a2958d028f9b	6379154765	swift	3	3			https://plisio.net/invoice/6ac89ed03e61a2958d028f9b	https://plisio.net/invoice/6ac89ed03e61a2958d028f9b	CHKXWIZ_6379154765_swift_1791532750	Paid	2026-10-09 07:59:14.845703	2026-10-09 14:14:28.164595
6ac8f6f7d7fbba2f7e05fafa	8663262466	swift	3	3			https://plisio.net/invoice/6ac8f6f7d7fbba2f7e05fafa	https://plisio.net/invoice/6ac8f6f7d7fbba2f7e05fafa	CHKXWIZ_8663262466_swift_1791555318	Paid	2026-10-09 14:15:22.301616	2026-10-09 15:16:11.704088
6acbc03c5b8d09af4e0d07c7	8961205934	swift	3	3			https://plisio.net/invoice/6acbc03c5b8d09af4e0d07c7	https://plisio.net/invoice/6acbc03c5b8d09af4e0d07c7	CHKXWIZ_8961205934_swift_1791737916	Pending	2026-10-11 16:58:38.916404	\N
6ace8804becad22471034b98	8423281554	swift	3	3			https://plisio.net/invoice/6ace8804becad22471034b98	https://plisio.net/invoice/6ace8804becad22471034b98	CHKXWIZ_8423281554_swift_1791920129	Pending	2026-10-13 19:35:35.535892	\N
6ace8ac197759edde6006425	8423281554	swift	3	3			https://plisio.net/invoice/6ace8ac197759edde6006425	https://plisio.net/invoice/6ace8ac197759edde6006425	CHKXWIZ_8423281554_swift_1791920833	Pending	2026-10-13 19:47:15.921589	\N
6ad2586b5a50307de3075a6f	8961205934	swift	3	3			https://plisio.net/invoice/6ad2586b5a50307de3075a6f	https://plisio.net/invoice/6ad2586b5a50307de3075a6f	CHKXWIZ_8961205934_swift_1792170090	Pending	2026-10-16 17:01:33.816251	\N
6ad2586b43f654f89001f351	8961205934	swift	3	3			https://plisio.net/invoice/6ad2586b43f654f89001f351	https://plisio.net/invoice/6ad2586b43f654f89001f351	CHKXWIZ_8961205934_swift_1792170086	Pending	2026-10-16 17:01:33.818891	\N
6ad2586da3c109dbde078c51	8961205934	turbo	7	7			https://plisio.net/invoice/6ad2586da3c109dbde078c51	https://plisio.net/invoice/6ad2586da3c109dbde078c51	CHKXWIZ_8961205934_turbo_1792170092	Pending	2026-10-16 17:01:35.401134	\N
6ad2586ecc2349a0270a6d67	8961205934	nitro	14	14			https://plisio.net/invoice/6ad2586ecc2349a0270a6d67	https://plisio.net/invoice/6ad2586ecc2349a0270a6d67	CHKXWIZ_8961205934_nitro_1792170093	Pending	2026-10-16 17:01:36.979697	\N
6ad25884fcd2bdf9480eee73	8961205934	apex	25	25			https://plisio.net/invoice/6ad25884fcd2bdf9480eee73	https://plisio.net/invoice/6ad25884fcd2bdf9480eee73	CHKXWIZ_8961205934_apex_1792170116	Pending	2026-10-16 17:01:59.300293	\N
\.


--
-- Data for Name: proxies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proxies (id, user_id, proxy, added_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipts (id, receipt_id, user_id, plan, amount_paid, purchased_on, expires_on) FROM stdin;
1	CHK-615629-XWIZ	8423281554	ᴏꪝɴᴇʀ	0	2026-09-30 08:13:30.488316	2027-09-30 08:13:30.488177
2	CHK-751449-XWIZ	8875733716	ꕶᴡ𝖎ғ†	0	2026-10-01 18:14:03.752391	2026-10-02 18:14:03.752333
3	CHK-578853-XWIZ	8388267028	swift	3	2026-10-07 18:38:47.625262	2026-10-09 18:38:47.621005
4	CHK-376525-XWIZ	8875733716	swift	3	2026-10-08 15:44:07.501728	2026-10-10 15:44:07.497975
5	CHK-384089-XWIZ	6379154765	ꕶᴡ𝖎ғ†	3	2026-10-09 08:00:33.045027	2026-10-11 08:00:33.044827
6	CHK-903591-XWIZ	6379154765	swift	3	2026-10-09 14:14:28.172362	2026-10-13 08:00:33.044827
7	CHK-454755-XWIZ	8663262466	swift	3	2026-10-09 15:16:11.719478	2026-10-11 15:16:11.711279
8	CHK-872752-XWIZ	8961205934	ꕶᴡ𝖎ғ†	3	2026-10-11 16:55:34.925651	2026-10-13 16:55:34.925313
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, username, credits, cc_checked, cc_charged, joined_at, cc_charged_lifetime, cc_approved_lifetime, cc_declined_lifetime, first_name, is_premium, premium_expiry, cards_generated, sk_checked, sk_charged) FROM stdin;
8663262466	unknown	150	0	0	2026-10-09 14:15:10.04596	0	0	0	yashuwnth	0	\N	0	0	0
8961205934	Krish_py	129	10350	138	2026-10-11 16:50:53.366961	33	104	10189	Krish	0	\N	0	0	0
8388267028	unknown	150	182	12	2026-10-07 17:30:13.775162	2	6	84	lwatery	0	\N	0	0	0
6379154765	unknown	150	8170	49	2026-10-09 07:58:14.806347	17	31	8113	TIGeR	0	\N	0	0	0
8423281554	unknown	999940801	59779	743	2026-09-30 04:28:57.22429	203	495	57508	『𝙑𝙊𝙍𝙏𝙀𒉽』𒉼 𝔦 乙	1	2027-09-30 08:13:30.488177	40	1	0
8875733716	rapewthyou	150	3106	77	2026-10-01 17:32:19.759906	22	55	3010	⋆⎯፝֟፝֟⎯᪵. 𝐈 𝐓 𝐀 𝐂 𝐇 𝐈 ×͜× 🧿	0	\N	0	0	0
8241482207	DEADxNrYn	150	0	0	2026-09-30 08:54:44.367293	0	0	0	\N	0	\N	0	0	0
\.


--
-- Name: global_proxies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.global_proxies_id_seq', 188, true);


--
-- Name: proxies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proxies_id_seq', 1, false);


--
-- Name: receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipts_id_seq', 8, true);


--
-- Name: banned_users banned_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banned_users
    ADD CONSTRAINT banned_users_pkey PRIMARY KEY (user_id);


--
-- Name: bot_settings bot_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_settings
    ADD CONSTRAINT bot_settings_pkey PRIMARY KEY (key);


--
-- Name: bot_state bot_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_state
    ADD CONSTRAINT bot_state_pkey PRIMARY KEY (key);


--
-- Name: codes codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.codes
    ADD CONSTRAINT codes_pkey PRIMARY KEY (code);


--
-- Name: gate_status gate_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gate_status
    ADD CONSTRAINT gate_status_pkey PRIMARY KEY (gate);


--
-- Name: global_proxies global_proxies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_proxies
    ADD CONSTRAINT global_proxies_pkey PRIMARY KEY (id);


--
-- Name: global_proxies global_proxies_proxy_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_proxies
    ADD CONSTRAINT global_proxies_proxy_key UNIQUE (proxy);


--
-- Name: payment_tracks payment_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_tracks
    ADD CONSTRAINT payment_tracks_pkey PRIMARY KEY (track_id);


--
-- Name: proxies proxies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxies
    ADD CONSTRAINT proxies_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_receipt_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_receipt_id_key UNIQUE (receipt_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_payment_tracks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_tracks_status ON public.payment_tracks USING btree (status);


--
-- Name: idx_payment_tracks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_tracks_user ON public.payment_tracks USING btree (user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict aD6saFdcbcYK2Lnmffem97UHtoHINERcjAC5EThkIrDdRSRZsxve6RAaNG4bbhp

